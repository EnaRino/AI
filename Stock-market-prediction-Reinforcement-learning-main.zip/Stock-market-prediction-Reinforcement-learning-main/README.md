# Stock-market-prediction-Reinforcement-learning
Trying out reinforcement agents to predict stock market for 3 interested companies

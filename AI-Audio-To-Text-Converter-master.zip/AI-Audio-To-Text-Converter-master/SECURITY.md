# Security Policy

## Reporting a Vulnerability

We take the security of this project seriously. If you discover a vulnerability, please notify us immediately.

**Do not open a public issue.** Instead, please email us directly at:
**souravkr529@gmail.com**

We will prioritize your report and work to address the issue as quickly as possible.

## Supported Versions

Only the latest version of this code (currently `v1.0`) is supported with security updates.

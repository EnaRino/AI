#  Resume Matcher AI

An AI-powered web application that automatically matches your resume with relevant job roles using natural language processing and keyword matching techniques. Just upload your resume PDF and get the top job matches based on your skills and experience!

---

##  Features

-  Upload your **resume (PDF format)**
-  Automatically extract **skills & keywords**
-  Match resume with available **job descriptions**
-  Display top job matches with **match scores**
-  Built using **Python, Flask, Pandas, and NLP**

---

##  Tech Stack

- **Frontend**: HTML, CSS (Bootstrap)
- **Backend**: Python, Flask
- **Libraries**: PyPDF2, pandas, scikit-learn (TfidfVectorizer)
- **NLP Techniques**: TF-IDF Vectorization, Cosine Similarity

---

##  How it Works

1. Upload your resume (PDF)
2. Extract text and clean using basic NLP
3. Compare your resume content against a list of job descriptions
4. Score matches based on TF-IDF vector similarity
5. Display top 5 job roles with match percentage


---

##  Local Setup

```bash
# 1. Clone this repo
git clone https://github.com/YOUR_USERNAME/resume-job-matcher-ai.git
cd resume-job-matcher-ai

# 2. Create virtual environment
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Run the app
python app.py

👩‍💻 Made by
Shailaja S P
Final Year CSE | Data Science, Web & AI Enthusiast
LinkedIn • GitHub

License
This project is licensed under the MIT License.


# FaceGeneration
Using generative adversarial networks (GAN) to generate new images of faces from celebrity images.

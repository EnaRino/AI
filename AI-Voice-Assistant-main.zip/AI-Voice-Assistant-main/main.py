import speech_recognition as sr
import webbrowser
import pyttsx3
import music_Library
import requests
from openai import OpenAI
import config

recognizer = sr.Recognizer()
engine = pyttsx3.init()

client = OpenAI(api_key=config.openai_api_key)

def speak(text):
    engine.say(text)
    engine.runAndWait()
    engine.stop

def processAi(command):
    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": command}
        ],
        max_tokens=150,
        temperature=0.7
    )
    return response.choices[0].message.content


def processCommand(c):
    if "open google" in c.lower():
        webbrowser.open("https://www.google.com/")
    elif "open youtube" in c.lower():
        webbrowser.open("https://www.youtube.com/")
    elif "open facebook" in c.lower():
        webbrowser.open("https://www.facebook.com/")
    elif "open trust" in c.lower():
        webbrowser.open("https://realwelfaretrust.org/") 
    
    elif c.lower().startswith("play"):
        song = c.lower().split(" ")[1]
        link = music_Library.music[song]
        print(song)
        webbrowser.open(link)

    elif "news" in c.lower():
        r = requests.get(f"https://newsapi.org/v2/top-headlines?country=pk&apiKey={config.news_api_key}")
        
        if r.status_code == 200:
            data = r.json()
            articles = data["articles"]

            if len(articles) == 0:
                print("No news found for Pakistan. Switching to US headlines.")
                speak("No news found for Pakistan. Switching to US headlines.")
                url = f"https://newsapi.org/v2/top-headlines?country=us&apiKey={newsapi}"
                response = requests.get(url)
                data = response.json()
                articles = data["articles"]

            speak("Here are the top headlines.")
            
            for i, article in enumerate(articles[:5], 1):  # Limit to top 5
                headline = f"Headline {i}: {article['title']}"
                print(headline)
                speak(headline)

                with sr.Microphone() as source:
                    print("Say 'stop' to cancel or wait to continue...")
                    try:
                        audio = recognizer.listen(source, timeout=3, phrase_time_limit=2)
                        command = recognizer.recognize_google(audio).lower()
                        if "stop" in command or "cancel" in command:
                            print("Stopping the news.")
                            speak("Stopping the news.")
                            break
                    except:
                        continue  # If no voice detected, continue

        else:
            speak(f"Sorry, I couldn't fetch the news. Status code: {r.status_code}")

    else:
        output = processAi(c)
        print(output)
        speak(output)

if __name__ == "__main__":
    speak("say harry to activate me")
    print("Say Harry to activate me")

    while True:
        r = sr.Recognizer()
        
        try:
            with sr.Microphone() as source:
                print("Listening...")
                audio = r.listen(source, timeout = 5, phrase_time_limit=3)   

            word = r.recognize_google(audio)
            
            if word.lower() == "harry":
                speak("Yes, I'm listening.")
                print("Harry Activated...")

                # Enter command loop
                while True:
                    try:
                        with sr.Microphone() as source:
                            print("Waiting for command...")
                            audio = r.listen(source, timeout=5, phrase_time_limit=4)
                            command = r.recognize_google(audio).lower()
                            print(f"Command: {command}")

                            # If user says "deactivate", break inner loop
                            if "deactivate" in command:
                                print("Okay, deactivating.")
                                speak("Okay, deactivating.")
                                break

                            # Otherwise, process command
                            processCommand(command)
                    except Exception as e:
                        print("No Voice Detected... {0}".format(e))  
        except Exception as e:
            print("No Voice Detected... {0}".format(e))              
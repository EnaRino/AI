
OPENAI_API_KEY = "your-openai-key-here"
NEWSAPI_KEY = "your-newsapi-key-here"
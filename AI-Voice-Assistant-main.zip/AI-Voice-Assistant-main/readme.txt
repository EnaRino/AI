# 🎙️ AI Voice Assistant (Code Name: Harry)

This is a Python-based voice assistant that can respond to voice commands, interact with the OpenAI API, open websites, play songs from a custom music library, fetch news, and respond in English or Urdu.

---

## 🚀 Features

- 🎧 **Voice Activation**: Say "Harry" to activate the assistant.
- 💬 **OpenAI GPT Integration**: Ask anything, and it replies using GPT-3.5-turbo.
- 🌐 **Web Commands**: Opens websites like Google, YouTube, Facebook, and custom links.
- 📰 **News Headlines**: Fetches top headlines using NewsAPI (default: Pakistan).
- 🎵 **Music Player**: Plays songs via a custom `music_Library.py`.
- 🔊 **Text-to-Speech**: Speaks responses using `pyttsx3` (or `gTTS` for Urdu if needed).
- 🗣️ **Multilingual Ready**: Can understand and reply in Urdu using Google Speech Recognition.

---

## 🧠 Technologies Used

- [`speech_recognition`](https://pypi.org/project/SpeechRecognition/)
- [`pyttsx3`](https://pypi.org/project/pyttsx3/)
- [`gtts`](https://pypi.org/project/gTTS/) *(optional for Urdu output)*
- [`requests`](https://pypi.org/project/requests/)
- [`webbrowser`](https://docs.python.org/3/library/webbrowser.html)
- [`openai`](https://pypi.org/project/openai/)

---

## 🔧 Setup Instructions

### 1. Clone the Repository

git clone https://github.com/Haris-Mahmood-21/AI-VOICE-ASSISTANT.git

2. Install Requirements

pip install -r requirements.txt

Or manually:

pip install openai speechrecognition pyttsx3 requests gTTS

3. Set Your API Keys

Create a file named `config.py` (do NOT share this file).

Paste your keys like this:

# config.py

OPENAI_API_KEY = "your-openai-key-here"

NEWSAPI_KEY = "your-newsapi-key-here"

🗂️ Project Structure

voice-assistant-harry/
│
├── main.py                # Main voice assistant logic
├── music_Library.py       # Dictionary of song names and URLs
├── config.py              # 🔐 API keys (DO NOT push to GitHub)
├── config_sample.py       # 🔓 Template for config
├── requirements.txt       # List of dependencies
├── .gitignore             # Prevents secret/config files from being tracked
└── README.md              # Project documentation

🛠️ music_Library.py Example

music = {
    "song1": "https://www.youtube.com/watch?v=xyz",
    "song2": "https://open.spotify.com/track/abc"
}

💡 Usage

Run the assistant:

python main.py

Then say:

"Harry" → to activate

"Open Google" → opens Google

"Play news" → speaks news headlines

"Play song1" → plays from music library

"Who is Elon Musk?" → gets a response from GPT

"Deactivate" → stops listening

🌍 Language Support

By default, the assistant listens in English.

To recognize Urdu, set:

r.recognize_google(audio, language="ur-PK")


📄 License

This project is for educational use. Feel free to modify and enhance it.

🙌 Credits

Developed by Muhammad Haris, powered by:

OpenAI

Google Speech Recognition

NewsAPI    

🛡️ Security Note

API keys are stored securely in `config.py` and are excluded from version control using `.gitignore`.
Never share this file publicly. Always use `config_sample.py` for sharing templates.
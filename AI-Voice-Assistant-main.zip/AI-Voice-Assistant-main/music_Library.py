music = {
    "pal" : "https://youtu.be/8of5w7RgcTc?si=mS0tKBZhpXtF5Ny1",
    "afsos" : "https://youtu.be/2FhgKp_lfJQ?si=r5QKst0tZ0wsuiTT",

}
import streamlit as st
from langchain.llms import OpenAI
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain
from newspaper import Article
from dotenv import load_dotenv

load_dotenv()

st.set_page_config(page_title="Smart Article Summarizer", layout="centered")
st.title("🧠 Smart Article Summarizer")

url = st.text_input("Enter the article URL:")

if url:
    try:
        st.info("⏳ Extracting article text...")
        article = Article(url)
        article.download()
        article.parse()

        if not article.text.strip():
            st.error("❌ Couldn't extract text from the article.")
        else:
            st.success("✅ Text extracted. Generating summary...")

            llm = OpenAI(temperature=0.5)
            prompt = PromptTemplate(
                input_variables=["text"],
                template="Summarize the following article in 5 sentences:\n\n{text}"
            )
            chain = LLMChain(llm=llm, prompt=prompt)
            summary = chain.run(article.text[:3500])  # limit input size

            st.subheader("🔍 Summary:")
            st.write(summary)

    except Exception as e:
        st.error(f"❌ Error: {e}")

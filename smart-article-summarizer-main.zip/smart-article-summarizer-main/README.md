# 🧠 Smart Article Summarizer

This project implements a simple web app that summarizes any article from the web using an LLM (like OpenAI's GPT) and content extraction tools like `newspaper3k`.

## 🚀 Features

- Input a URL and get a concise summary.
- Uses `newspaper3k` to extract clean article text.
- Uses `LangChain` with OpenAI or Hugging Face models.
- Streamlit interface for ease of use.

## 🧰 Stack

- Python 3.10+
- Streamlit
- LangChain
- OpenAI or HuggingFace
- newspaper3k

## 🔧 Installation

```bash
git clone https://github.com/your-username/smart-article-summarizer.git
cd smart-article-summarizer
python -m venv venv
source venv/bin/activate  # or venv\Scripts\activate on Windows
pip install -r requirements.txt
```

## 🔑 API Key

Set your OpenAI API key:

```bash
export OPENAI_API_KEY="your-key-here"
# Or create a .env file and use python-dotenv
```

## ▶️ Run the App

```bash
streamlit run app.py
```

## 📝 Example

- Input: `https://app.daily.dev/posts/claude-4-you-better-stop-coding-now-ezu32jndg`
- Output: A 5-sentence summary of the article

[![Follow on GitHub](https://img.shields.io/github/followers/reinelt88?label=Follow&style=social)](https://github.com/reinelt88)

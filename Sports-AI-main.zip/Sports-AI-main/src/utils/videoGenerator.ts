import OpenAI from 'openai'
import { S3Client, PutObjectCommand } from '@aws-sdk/client-s3'
import { getSignedUrl } from '@aws-sdk/s3-request-presigner'

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
})

const s3Client = new S3Client({
  region: process.env.AWS_REGION!,
  credentials: {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID!,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY!,
  },
})

export async function generateScript(celebrity: string, sport: string): Promise<string> {
  const prompt = `Write a short, engaging script about ${celebrity}'s most memorable moments in ${sport}. 
    Focus on their achievements, impact, and legacy. Keep it under 100 words.`

  const completion = await openai.chat.completions.create({
    messages: [{ role: 'user', content: prompt }],
    model: 'gpt-4',
  })

  return completion.choices[0].message.content || ''
}

export async function uploadToS3(file: Buffer, key: string): Promise<string> {
  const command = new PutObjectCommand({
    Bucket: process.env.AWS_S3_BUCKET!,
    Key: key,
    Body: file,
    ContentType: 'video/mp4',
  })

  await s3Client.send(command)
  
  // Generate a signed URL for the uploaded video
  const signedUrl = await getSignedUrl(s3Client, command, { expiresIn: 3600 })
  return signedUrl
}

// TODO: Implement video generation using FFmpeg
export async function generateVideo(script: string, images: string[]): Promise<Buffer> {
  // This is a placeholder for the actual video generation logic
  // You'll need to implement this using FFmpeg or another video processing library
  throw new Error('Video generation not implemented')
} 
import OpenAI from 'openai'

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
})

export async function generateScript(celebrity: string, sport: string): Promise<string> {
  try {
    const prompt = `Create a short, engaging script for a TikTok-style video about ${celebrity}'s history in ${sport}. 
    The script should be concise (max 150 words), engaging, and highlight key achievements or memorable moments. 
    Make it sound natural and conversational.`

    const completion = await openai.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: 'You are a creative sports content writer who specializes in creating engaging, short-form content.'
        },
        {
          role: 'user',
          content: prompt
        }
      ],
      model: 'gpt-3.5-turbo',
      max_tokens: 200,
      temperature: 0.7,
    })

    return completion.choices[0]?.message?.content || 'Failed to generate script'
  } catch (error) {
    console.error('Error in generateScript:', error)
    throw new Error('Failed to generate script')
  }
} 
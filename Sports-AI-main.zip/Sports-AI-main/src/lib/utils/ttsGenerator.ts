import { PollyClient, SynthesizeSpeechCommand } from '@aws-sdk/client-polly'

const pollyClient = new PollyClient({
  region: process.env.AWS_REGION,
  credentials: {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID!,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY!,
  },
})

export async function generateSpeech(text: string): Promise<Buffer> {
  try {
    const command = new SynthesizeSpeechCommand({
      Text: text,
      OutputFormat: 'mp3',
      VoiceId: 'Joanna', // You can change this to other voices
      Engine: 'neural', // Using neural engine for better quality
    })

    const response = await pollyClient.send(command)
    
    if (!response.AudioStream) {
      throw new Error('No audio stream received from Polly')
    }

    // Convert the audio stream to a buffer
    const chunks: Uint8Array[] = []
    for await (const chunk of response.AudioStream) {
      chunks.push(chunk)
    }
    
    return Buffer.concat(chunks)
  } catch (error) {
    console.error('Error generating speech:', error)
    throw new Error('Failed to generate speech')
  }
} 
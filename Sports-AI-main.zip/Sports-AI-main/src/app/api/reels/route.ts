import { NextResponse } from 'next/server'

// TODO: Replace with actual database integration
const mockReels = [
  {
    id: '1',
    title: 'Michael Jordan: The GOAT',
    videoUrl: '/videos/jordan.mp4',
    celebrity: 'Michael Jordan',
    sport: 'Basketball',
  },
  {
    id: '2',
    title: 'Muhammad Ali: The Greatest',
    videoUrl: '/videos/ali.mp4',
    celebrity: 'Muhammad Ali',
    sport: 'Boxing',
  },
]

export async function GET() {
  // TODO: Add error handling and database integration
  return NextResponse.json(mockReels)
} 
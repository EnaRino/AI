import { NextResponse } from 'next/server'
import { generateScript } from '@/lib/utils/videoGenerator'
import { generateSpeech } from '@/lib/utils/ttsGenerator'

export async function POST(request: Request) {
  try {
    const { celebrity, sport } = await request.json()

    if (!celebrity || !sport) {
      return NextResponse.json(
        { error: 'Celebrity and sport are required' },
        { status: 400 }
      )
    }

    // Generate script using OpenAI
    const script = await generateScript(celebrity, sport)

    // Generate speech using Amazon Polly
    const audioBuffer = await generateSpeech(script)

    // Convert buffer to base64 for sending in response
    const audioBase64 = audioBuffer.toString('base64')

    return NextResponse.json({ 
      script,
      audio: audioBase64,
      audioFormat: 'mp3'
    })
  } catch (error) {
    console.error('Error generating reel:', error)
    return NextResponse.json(
      { error: 'Failed to generate reel' },
      { status: 500 }
    )
  }
} 
import ReelFeed from '@/components/ReelFeed'
import GenerateReelForm from '@/components/GenerateReelForm'

export default function Home() {
  return (
    <div className="flex flex-col items-center w-full max-w-md mx-auto">
      <h1 className="text-2xl font-bold my-4">Sports History Reels</h1>
      <GenerateReelForm />
      <div className="w-full mt-8">
        <ReelFeed />
      </div>
    </div>
  )
}

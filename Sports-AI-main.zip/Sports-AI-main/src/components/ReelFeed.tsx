'use client'

import { useState, useEffect } from 'react'
import Reel from './Reel'

interface ReelData {
  id: string
  title: string
  videoUrl: string
  celebrity: string
  sport: string
}

export default function ReelFeed() {
  const [reels, setReels] = useState<ReelData[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // TODO: Fetch reels from API
    const fetchReels = async () => {
      try {
        const response = await fetch('/api/reels')
        const data = await response.json()
        setReels(data)
      } catch (error) {
        console.error('Error fetching reels:', error)
      } finally {
        setLoading(false)
      }
    }

    fetchReels()
  }, [])

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-white"></div>
      </div>
    )
  }

  return (
    <div className="w-full h-screen overflow-y-scroll snap-y snap-mandatory">
      {reels.map((reel) => (
        <div key={reel.id} className="h-screen snap-start">
          <Reel reel={reel} />
        </div>
      ))}
    </div>
  )
} 
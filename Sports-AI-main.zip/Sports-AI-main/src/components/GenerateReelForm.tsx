'use client'

import { useState } from 'react'

export default function GenerateReelForm() {
  const [celebrity, setCelebrity] = useState('')
  const [sport, setSport] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [script, setScript] = useState('')
  const [audioUrl, setAudioUrl] = useState<string | null>(null)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError('')
    setScript('')
    setAudioUrl(null)

    try {
      const response = await fetch('/api/reels/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ celebrity, sport }),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || 'Failed to generate reel')
      }

      setScript(data.script)
      
      // Create audio URL from base64 data
      const audioBlob = new Blob(
        [Buffer.from(data.audio, 'base64')],
        { type: `audio/${data.audioFormat}` }
      )
      const url = URL.createObjectURL(audioBlob)
      setAudioUrl(url)
      
      // Reset form
      setCelebrity('')
      setSport('')
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to generate reel. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="w-full max-w-md p-4 space-y-4">
      <div>
        <label htmlFor="celebrity" className="block text-sm font-medium mb-1">
          Sports Celebrity
        </label>
        <input
          type="text"
          id="celebrity"
          value={celebrity}
          onChange={(e) => setCelebrity(e.target.value)}
          className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          placeholder="e.g., Michael Jordan"
          required
        />
      </div>

      <div>
        <label htmlFor="sport" className="block text-sm font-medium mb-1">
          Sport
        </label>
        <input
          type="text"
          id="sport"
          value={sport}
          onChange={(e) => setSport(e.target.value)}
          className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          placeholder="e.g., Basketball"
          required
        />
      </div>

      {error && (
        <p className="text-red-500 text-sm">{error}</p>
      )}

      {script && (
        <div className="mt-4 p-4 bg-gray-800 rounded-md">
          <h3 className="text-lg font-medium mb-2">Generated Script:</h3>
          <p className="text-gray-300">{script}</p>
        </div>
      )}

      {audioUrl && (
        <div className="mt-4">
          <h3 className="text-lg font-medium mb-2">Generated Audio:</h3>
          <audio controls className="w-full">
            <source src={audioUrl} type="audio/mp3" />
            Your browser does not support the audio element.
          </audio>
        </div>
      )}

      <button
        type="submit"
        disabled={loading}
        className="w-full px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
      >
        {loading ? 'Generating...' : 'Generate Reel'}
      </button>
    </form>
  )
} 
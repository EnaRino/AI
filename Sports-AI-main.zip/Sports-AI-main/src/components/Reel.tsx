'use client'

import { useRef, useEffect } from 'react'

interface ReelProps {
  reel: {
    id: string
    title: string
    videoUrl: string
    celebrity: string
    sport: string
  }
}

export default function Reel({ reel }: ReelProps) {
  const videoRef = useRef<HTMLVideoElement>(null)

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            videoRef.current?.play()
          } else {
            videoRef.current?.pause()
          }
        })
      },
      { threshold: 0.5 }
    )

    if (videoRef.current) {
      observer.observe(videoRef.current)
    }

    return () => {
      if (videoRef.current) {
        observer.unobserve(videoRef.current)
      }
    }
  }, [])

  return (
    <div className="relative h-full w-full">
      <video
        ref={videoRef}
        src={reel.videoUrl}
        className="w-full h-full object-cover"
        loop
        playsInline
        muted
      />
      <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/80 to-transparent">
        <h2 className="text-xl font-bold">{reel.title}</h2>
        <p className="text-sm text-gray-200">
          {reel.celebrity} • {reel.sport}
        </p>
      </div>
    </div>
  )
} 